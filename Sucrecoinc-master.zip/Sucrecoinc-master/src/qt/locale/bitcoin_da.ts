<TS language="da" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Højreklik for at redigere adresse eller mærke</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Opret en ny adresse</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Ny</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopiér den valgte adresse til systemets udklipsholder</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiér</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Luk</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Kopiér adresse</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Slet den markerede adresse fra listen</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportér den aktuelle visning til en fil</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Eksportér</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Slet</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Vælg adresse at sende litecoins til</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Vælg adresse at modtage litecoins med</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;Vælg</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Afsendelsesadresser</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Modtagelsesadresser</translation>
    </message>
    <message>
        <source>These are your Sucrecoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Disse er dine Sucrecoin-adresser for at sende betalinger. Tjek altid beløb og modtageradresse, inden du sender litecoins.</translation>
    </message>
    <message>
        <source>These are your Sucrecoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Dette er dine Sucrecoin-adresser til at modtage betalinger med. Det anbefales are bruge en ny modtagelsesadresse for hver transaktion.</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Kopiér &amp;mærkat</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Redigér</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Eksportér adresseliste</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommasepareret fil (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Eksport mislykkedes</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Der opstod en fejl under gemning af adresselisten til %1. Prøv venligst igen.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Adgangskodedialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Indtast adgangskode</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Ny adgangskode</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Gentag ny adgangskode</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Kryptér tegnebog</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Denne funktion har brug for din tegnebogs adgangskode for at låse tegnebogen op.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Lås tegnebog op</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Denne funktion har brug for din tegnebogs adgangskode for at dekryptere tegnebogen.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Dekryptér tegnebog</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Skift adgangskode</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Indtast den gamle og den nye adgangskode til tegnebogen.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Bekræft tegnebogskryptering</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR LITECOINS&lt;/b&gt;!</source>
        <translation>Advarsel: Hvis du krypterer din tegnebog og mister din adgangskode, vil du &lt;b&gt;MISTE ALLE DINE LITECOINS&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Er du sikker på, at du ønsker at kryptere din tegnebog?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>VIGTIGT: Enhver tidligere sikkerhedskopi, som du har lavet af tegnebogsfilen, bør blive erstattet af den nyligt genererede, krypterede tegnebogsfil. Af sikkerhedsmæssige årsager vil tidligere sikkerhedskopier af den ikke-krypterede tegnebogsfil blive ubrugelige i det øjeblik, du starter med at anvende den nye, krypterede tegnebog.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Advarsel: Caps Lock-tasten er aktiveret!</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Tegnebog krypteret</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Indtast det nye kodeord til tegnebogen.&lt;br/&gt;Brug venligst et kodeord på &lt;b&gt;ti eller flere tilfældige tegn&lt;/b&gt; eller &lt;b&gt;otte eller flere ord&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Sucrecoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your litecoins from being stolen by malware infecting your computer.</source>
        <translation>Sucrecoin vil nu lukke for at gennemføre krypteringsprocessen. Husk på, at kryptering af din tegnebog vil ikke beskytte dine litecoins fuldt ud mod at blive stjålet af malware på din computer.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Tegnebogskryptering mislykkedes</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Tegnebogskryptering mislykkedes på grund af en intern fejl. Din tegnebog blev ikke krypteret.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>De angivne adgangskoder stemmer ikke overens.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Tegnebogsoplåsning mislykkedes</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Den angivne adgangskode for tegnebogsdekrypteringen er forkert.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Tegnebogsdekryptering mislykkedes</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Tegnebogens adgangskode blev ændret.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Underskriv &amp;besked …</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synkroniserer med netværk …</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Oversigt</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Knude</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Vis generel oversigt over tegnebog</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaktioner</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Gennemse transaktionshistorik</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Luk</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Afslut program</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Om &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Vis informationer om Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Indstillinger …</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Kryptér tegnebog …</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Sikkerhedskopiér tegnebog …</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Skift adgangskode …</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Afsendelsesadresser …</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Modtagelsesadresser …</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>&amp;Åbn URI …</translation>
    </message>
    <message>
        <source>Sucrecoin Core client</source>
        <translation>Sucrecoin Core-klient</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>Importerer blokke fra disken …</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Genindekserer blokke på disken …</translation>
    </message>
    <message>
        <source>Send coins to a Sucrecoin address</source>
        <translation>Send litecoins til en Sucrecoin-adresse</translation>
    </message>
    <message>
        <source>Modify configuration options for Sucrecoin</source>
        <translation>Redigér konfigurationsindstillinger for Sucrecoin</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Lav sikkerhedskopi af tegnebogen til et andet sted</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Skift adgangskode anvendt til tegnebogskryptering</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Fejlsøgningsvindue</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Åbn fejlsøgnings- og diagnosticeringskonsollen</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verificér besked …</translation>
    </message>
    <message>
        <source>Sucrecoin</source>
        <translation>Sucrecoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Tegnebog</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Send</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Modtag</translation>
    </message>
    <message>
        <source>Show information about Sucrecoin Core</source>
        <translation>Vis oplysninger om Sucrecoin Core</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Vis / skjul</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Vis eller skjul hovedvinduet</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Kryptér de private nøgler, der hører til din tegnebog</translation>
    </message>
    <message>
        <source>Sign messages with your Sucrecoin addresses to prove you own them</source>
        <translation>Underskriv beskeder med dine Sucrecoin-adresser for at bevise, at de tilhører dig</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Sucrecoin addresses</source>
        <translation>Verificér beskeder for at sikre, at de er underskrevet med de angivne Sucrecoin-adresser</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fil</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Opsætning</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hjælp</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Faneværktøjslinje</translation>
    </message>
    <message>
        <source>Sucrecoin Core</source>
        <translation>Sucrecoin Core</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and litecoin: URIs)</source>
        <translation>Anmod om betalinger (genererer QR-koder og "litecoin:"-URI'er)</translation>
    </message>
    <message>
        <source>&amp;About Sucrecoin Core</source>
        <translation>&amp;Om Sucrecoin Core</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Vis listen over brugte afsendelsesadresser og -mærkater</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Vis listen over brugte modtagelsesadresser og -mærkater</translation>
    </message>
    <message>
        <source>Open a litecoin: URI or payment request</source>
        <translation>Åbn en "litecoin:"-URI eller betalingsanmodning</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Tilvalg for &amp;kommandolinje</translation>
    </message>
    <message>
        <source>Show the Sucrecoin Core help message to get a list with possible Sucrecoin command-line options</source>
        <translation>Vis Sucrecoin Core hjælpebesked for at få en liste over mulige tilvalg for Sucrecoin kommandolinje</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Sucrecoin network</source>
        <translation><numerusform>%n aktiv forbindelse til Sucrecoin-netværket</numerusform><numerusform>%n aktive forbindelser til Sucrecoin-netværket</numerusform></translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>Ingen blokkilde tilgængelig …</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n time</numerusform><numerusform>%n timer</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n dag</numerusform><numerusform>%n dage</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n uge</numerusform><numerusform>%n uger</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 og %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n år</numerusform><numerusform>%n år</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 bagud</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Senest modtagne blok blev genereret for %1 siden.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transaktioner herefter vil endnu ikke være synlige.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Opdateret</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n blocks of transaction history.</source>
        <translation><numerusform>%n blok af transaktionshistorikken er blevet behandlet.</numerusform><numerusform>%n blokke af transaktionshistorikken er blevet behandlet.</numerusform></translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Indhenter …</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Afsendt transaktion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Indgående transaktion</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Dato: %1
Beløb: %2
Type: %3
Adresse: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Tegnebog er &lt;b&gt;krypteret&lt;/b&gt; og i øjeblikket &lt;b&gt;ulåst&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Tegnebog er &lt;b&gt;krypteret&lt;/b&gt; og i øjeblikket &lt;b&gt;låst&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>Netværksadvarsel</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Coin-styring</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Mængde:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritet:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebyr:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Støv:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Efter gebyr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Byttepenge:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(af)vælg alle</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Trætilstand</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listetilstand</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Modtaget med mærke</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Modtaget med adresse</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Bekræftelser</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bekræftet</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiér adresse</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiér mærkat</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiér beløb</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopiér transaktions-ID</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Fastlås ubrugte</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Lås ubrugte op</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Kopiér mængde</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Kopiér gebyr</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Kopiér efter-gebyr</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Kopiér byte</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Kopiér prioritet</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Kopiér støv</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Kopiér byttepenge</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>højest</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>højere</translation>
    </message>
    <message>
        <source>high</source>
        <translation>højt</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>mellemhøj</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>medium</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>mellemlav</translation>
    </message>
    <message>
        <source>low</source>
        <translation>lav</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>lavere</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>lavest</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 fastlåst)</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ingen</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation>Kan variere med +/- %1 satoshi per input.</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nej</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>Dette mærkat bliver rødt, hvis transaktionsstørrelsen er større end 1000 byte.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>Dette betyder, at et gebyr på mindst %1 pr. kB er nødvendigt.</translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>Kan variere ±1 byte pr. input.</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>Transaktioner med højere prioritet har højere sansynlighed for at blive inkluderet i en blok.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than "medium".</source>
        <translation>Dette mærkat bliver rødt, hvis prioriteten er mindre end "medium".</translation>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation>Dette mærkat bliver rødt, hvis mindst én modtager et beløb mindre end %1.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>byttepenge fra %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(byttepange)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Redigér adresse</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Mærkat</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Mærkatet, der er associeret med denne indgang i adresselisten</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Adressen, der er associeret med denne indgang i adresselisten. Denne kan kune ændres for afsendelsesadresser.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresse</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Ny modtagelsesadresse</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Ny afsendelsesadresse</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Redigér modtagelsesadresse</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Redigér afsendelsesadresse</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Den indtastede adresse "%1" er allerede i adressebogen.</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Sucrecoin address.</source>
        <translation>Den indtastede adresse "%1" er ikke en gyldig Sucrecoin-adresse.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Kunne ikke låse tegnebog op.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Ny nøglegenerering mislykkedes.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>En ny datamappe vil blive oprettet.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>navn</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Mappe eksisterer allerede. Tilføj %1, hvis du vil oprette en ny mappe her.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Sti eksisterer allerede og er ikke en mappe.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Kan ikke oprette en mappe her.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Sucrecoin Core</source>
        <translation>Sucrecoin Core</translation>
    </message>
    <message>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>About Sucrecoin Core</source>
        <translation>Om Sucrecoin Core</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Kommandolinjetilvalg</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Anvendelse:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>kommandolinjetilvalg</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>Brugergrænsefladeindstillinger</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>Angiv sprog, fx "da_DK" (standard: systemlokalitet)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Start minimeret</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>Sæt SSL-rodcertifikater for betalingsanmodning (standard: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Vis opstartsbillede ved opstart (standard: 1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>Vælg datamappe ved opstart (standard: 0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Velkommen</translation>
    </message>
    <message>
        <source>Welcome to Sucrecoin Core.</source>
        <translation>Velkommen til Sucrecoin Core.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Sucrecoin Core will store its data.</source>
        <translation>Siden dette er første gang, programmet startes, kan du vælge, hvor Sucrecoin Core skal gemme sin data.</translation>
    </message>
    <message>
        <source>Sucrecoin Core will download and store a copy of the Sucrecoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>Sucrecoin Core vil downloade og gemme et kopi af Sucrecoin-blokkæden. Mindst %1 GB data vil blive gemt i denne mappe, og den vil vokse over tid. Tegnebogen vil også blive gemt i denne mappe.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Brug standardmappen for data</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Brug tilpasset mappe for data:</translation>
    </message>
    <message>
        <source>Sucrecoin Core</source>
        <translation>Sucrecoin Core</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>Fejl: Angivet datamappe "%1" kan ikke oprettes.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation><numerusform>%n GB fri plads tilgængelig</numerusform><numerusform>%n GB fri plads tilgængelig</numerusform></translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Åbn URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Åbn betalingsanmodning fra URI eller fil</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Vælg fil for betalingsanmodning</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Vælg fil for betalingsanmodning til åbning</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Generelt</translation>
    </message>
    <message>
        <source>Automatically start Sucrecoin after logging in to the system.</source>
        <translation>Start Sucrecoin automatisk, når der logges ind på systemet.</translation>
    </message>
    <message>
        <source>&amp;Start Sucrecoin on system login</source>
        <translation>&amp;Start Sucrecoin ved systemlogin</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Størrelsen på &amp;databasens cache</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Antallet af script&amp;verificeringstråde</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Acceptér forbindelser udefra</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Tillad indkommende forbindelser</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP-adresse for proxyen (fx IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Tredjeparts-URL'er (fx et blokhåndteringsværktøj), der vises i transaktionsfanen som genvejsmenupunkter. %s i URL'en erstattes med transaktionens hash. Flere URL'er separeres med en lodret streg |.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Tredjeparts-transaktions-URL'er</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Aktuelle tilvalg for kommandolinjen, der tilsidesætter ovenstående tilvalg:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Nulstil alle klientindstillinger til deres standard.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Nulstil indstillinger</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Netværk</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = auto, &lt;0 = efterlad så mange kerner fri)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>&amp;Tegnebog</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Ekspert</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Slå egenskaber for &amp;coin-styring til</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Hvis du slår brug af ubekræftede byttepenge fra, kan byttepengene fra en transaktion ikke bruges, før pågældende transaktion har mindst én bekræftelse. Dette påvirker også måden hvorpå din saldo beregnes.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Brug ubekræftede byttepenge</translation>
    </message>
    <message>
        <source>Automatically open the Sucrecoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Åbn automatisk Sucrecoin-klientens port på routeren. Dette virker kun, når din router understøtter UPnP, og UPnP er aktiveret.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Konfigurér port vha. &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Sucrecoin network through a SOCKS5 proxy.</source>
        <translation>Forbind til Sucrecoin-netværket gennem en SOCKS5-proxy.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Forbind gennem SOCKS5-proxy (standard-proxy):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy-&amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port for proxyen (fx 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Vindue</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Vis kun et statusikon efter minimering af vinduet.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimér til statusfeltet i stedet for proceslinjen</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimér i stedet for at afslutte programmet, når vinduet lukkes. Når denne indstilling er valgt, vil programmet kun blive lukket, når du har valgt Afslut i menuen.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimér ved lukning</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Visning</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Sprog for brugergrænseflade:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Sucrecoin.</source>
        <translation>Sproget for brugergrænsefladen kan angives her. Denne indstilling træder først i kraft, når Sucrecoin genstartes.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Enhed at vise beløb i:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Vælg standard for underopdeling af enhed, som skal vises i brugergrænsefladen og ved afsendelse af litecoins.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Hvorvidt egenskaber for coin-styring skal vises eller ej.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;O.k.</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annullér</translation>
    </message>
    <message>
        <source>default</source>
        <translation>standard</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ingen</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Bekræft nulstilling af indstillinger</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Genstart af klienten er nødvendig for at aktivere ændringer.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>Klienten vil blive lukket ned; vil du fortsætte?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Denne ændring vil kræve en genstart af klienten.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Den angivne proxy-adresse er ugyldig.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Sucrecoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Den viste information kan være forældet. Din tegnebog synkroniserer automatisk med Sucrecoin-netværket, når en forbindelse etableres, men denne proces er ikke gennemført endnu.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Kigge:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Tilgængelig:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Din nuværende tilgængelige saldo</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Uafgjort:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Total saldo for transaktioner, som ikke er blevet bekræftet endnu, og som ikke endnu er en del af den tilgængelige saldo</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Umodne:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Minet saldo, som endnu ikke er modnet</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Saldi:</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Din nuværende totale saldo</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Din nuværende saldo på kigge-adresser</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Spendérbar:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Nylige transaktioner</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Ubekræftede transaktioner til kigge-adresser</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>Minet saldo på kigge-adresser, som endnu ikke er modnet</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Nuværende totalsaldo på kigge-adresser</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>ikke synkroniseret</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>URI-håndtering</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Ugyldig betalingsadresse %1</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>Betalingsanmodning afvist</translation>
    </message>
    <message>
        <source>Payment request network doesn't match client network.</source>
        <translation>Netværk for betalingsanmodning stemmer ikke overens med klientens netværk.</translation>
    </message>
    <message>
        <source>Payment request has expired.</source>
        <translation>Betalingsanmodning er udløbet.</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>Betalingsanmodning er ikke klargjort.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>Anmodet betalingsbeløb på %1 er for lille (regnes som støv).</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>Fejl i betalingsanmodning</translation>
    </message>
    <message>
        <source>Cannot start litecoin: click-to-pay handler</source>
        <translation>Kan ikke starte litecoin: click-to-pay-håndtering</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>Hentnings-URL for betalingsanmodning er ugyldig: %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Sucrecoin address or malformed URI parameters.</source>
        <translation>URI kan ikke tolkes! Dette kan skyldes en ugyldig Sucrecoin-adresse eller forkert udformede URL-parametre.</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Filhåndtering for betalingsanmodninger</translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>Fil for betalingsanmodning kan ikke læses! Dette kan skyldes en ugyldig fil for betalingsanmodning.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Ikke-verificerede betalingsanmodninger for tilpassede betalings-scripts understøttes ikke.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Tilbagebetaling fra %1</translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation>Betalingsanmodning %1 er for stor (%2 byte, %3 byte tilladt).</translation>
    </message>
    <message>
        <source>Payment request DoS protection</source>
        <translation>Beskyttelse mod DoS-angreb via betalingsanmodninger</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Fejl under kommunikation med %1: %2</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>Betalingsanmodning kan ikke tolkes!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Fejlagtigt svar fra server %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Betaling anerkendt</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Fejl i netværksforespørgsel</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Brugeragent</translation>
    </message>
    <message>
        <source>Address/Hostname</source>
        <translation>Adresse/værtsnavn</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Ping-tid</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>Enter a Sucrecoin address (e.g. %1)</source>
        <translation>Indtast en Sucrecoin-adresse (fx %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 d</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 t</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <source>NETWORK</source>
        <translation>NETVÆRK</translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation>UKENDT</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Gem billede …</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;Kopiér foto</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Gem QR-kode</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG-billede (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>Klientnavn</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Klientversion</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Fejlsøgningsvindue</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>Anvender OpenSSL-version</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Bruger BerkeleyDB version</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Opstartstidspunkt</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Netværk</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Antal forbindelser</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Blokkæde</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Nuværende antal blokke</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Modtaget</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Sendt</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>Andre &amp;knuder</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Vælg en anden knude for at se detaljeret information.</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Retning</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Brugeragent</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Tjenester</translation>
    </message>
    <message>
        <source>Starting Height</source>
        <translation>Starthøjde</translation>
    </message>
    <message>
        <source>Sync Height</source>
        <translation>Synkroniseringshøjde</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Bandlysningsscore</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Forbindelsestid</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Seneste afsendelse</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Seneste modtagelse</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation>Byte sendt</translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation>Byte modtaget</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Ping-tid</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Tidsstempel for seneste blok</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Åbn</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsol</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Netværkstrafik</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Ryd</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totaler</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Indkommende:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Udgående:</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>Byggedato</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Fejlsøgningslogfil</translation>
    </message>
    <message>
        <source>Open the Sucrecoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Åbn Sucrecoin-fejlsøgningslogfilen fra den nuværende datamappe. Dette kan tage nogle få sekunder for store logfiler.</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Ryd konsol</translation>
    </message>
    <message>
        <source>Welcome to the Sucrecoin RPC console.</source>
        <translation>Velkommen til Sucrecoin RPC-konsollen.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Brug op- og ned-piletasterne til at navigere i historikken og &lt;b&gt;Ctrl-L&lt;/b&gt; til at rydde skærmen.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Tast &lt;b&gt;help&lt;/b&gt; for en oversigt over de tilgængelige kommandoer.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>via %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>aldrig</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Indkommende</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Udgående</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Ukendt</translation>
    </message>
    <message>
        <source>Fetching...</source>
        <translation>Henter …</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Beløb:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Mærkat:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Besked:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Genbrug en af de tidligere brugte modtagelsesadresser. Genbrug af adresser har indflydelse på sikkerhed og privatliv. Brug ikke dette med mindre du genskaber en betalingsanmodning fra tidligere.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>&amp;Genbrug en eksisterende modtagelsesadresse (anbefales ikke)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Sucrecoin network.</source>
        <translation>En valgfri besked, der føjes til betalingsanmodningen, og som vil vises, når anmodningen åbnes. Bemærk: Beskeden vil ikke sendes sammen med betalingen over Sucrecoin-netværket.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Et valgfrit mærkat, der associeres med den nye modtagelsesadresse.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Brug denne formular for at anmode om betalinger. Alle felter er &lt;b&gt;valgfri&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Et valgfrit beløb til anmodning. Lad dette felt være tomt eller indeholde nul for at anmode om et ikke-specifikt beløb.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Ryd alle felter af formen.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Ryd</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Historik over betalingsanmodninger</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Anmod om betaling</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Vis den valgte anmodning (gør det samme som dobbeltklik på en indgang)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Fjern de valgte indgange fra listen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiér mærkat</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Kopiér besked</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopier beløb</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-kode</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Kopiér &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Kopiér &amp;adresse</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Gem billede …</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Anmod om betaling til %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Betalingsinformation</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Besked</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Resulterende URI var for lang; prøv at forkorte teksten til mærkaten/beskeden.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Fejl ved kodning fra URI til QR-kode.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Besked</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(ingen besked)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(intet beløb)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Send litecoins</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Egenskaber for coin-styring</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Inputs …</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>valgt automatisk</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Utilstrækkelige midler!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Mængde:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritet:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebyr:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Efter gebyr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Byttepenge:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Hvis dette aktiveres, men byttepengeadressen er tom eller ugyldig, vil byttepenge blive sendt til en nygenereret adresse.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Tilpasset byttepengeadresse</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Transaktionsgebyr:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Vælg …</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>sammenfold gebyropsætning</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimér</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then "per kilobyte" only pays 250 satoshis in fee, while "at least" pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Hvis det brugertilpassede gebyr er sat til 1000 satoshis, og transaktionen kun fylder 250 byte, betaler "pr. kilobyte" kun 250 satoshis i gebyr, mens "mindst" betaler 1000 satoshis. For transaktioner større end en kilobyte betaler begge pr. kilobyte.</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>pr. kilobyte</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then "per kilobyte" only pays 250 satoshis in fee, while "total at least" pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Hvis det brugertilpassede gebyr er sat til 1000 satoshis, og transaktionen kun fylder 250 byte, betaler "pr. kilobyte" kun 250 satoshis i gebyr, mens "total mindst" betaler 1000 satoshis. For transaktioner større end en kilobyte betaler begge pr. kilobyte.</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>total mindst</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for litecoin transactions than the network can process.</source>
        <translation>Det er helt fint kun at betale det minimale gebyr, så længe den totale transaktionsvolumen er mindre end den plads, der er tilgængelig i blokkene. Men vær opmærksom på, at dette kan ende ud i transaktioner, der aldrig bliver bekræftet, når der bliver større forespørgsel efter litecoin-transaktioner, end hvad netværket kan bearbejde.</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(læs værktøjstippet)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Anbefalet:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Brugertilpasset:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation>(Smart-gebyr er ikke initialiseret endnu. Dette tager typisk nogle få blokke …)</translation>
    </message>
    <message>
        <source>Confirmation time:</source>
        <translation>Bekræftelsestid:</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>fast</source>
        <translation>hurtig</translation>
    </message>
    <message>
        <source>Send as zero-fee transaction if possible</source>
        <translation>Send som nul-gebyr-transaktion hvis muligt</translation>
    </message>
    <message>
        <source>(confirmation may take longer)</source>
        <translation>(bekræftelse kan tage længere)</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Send til flere modtagere på en gang</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Tilføj &amp;modtager</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Ryd alle felter af formen.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Støv:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Ryd &amp;alle</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Bekræft afsendelsen</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Afsend</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Bekræft afsendelse af litecoins</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 til %2</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Kopiér mængde</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopier beløb</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Kopiér gebyr</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Kopiér efter-gebyr</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Kopiér byte</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Kopiér prioritet</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Kopiér byttepenge</translation>
    </message>
    <message>
        <source>Total Amount %1&lt;span style='font-size:10pt;font-weight:normal;'&gt;&lt;br /&gt;(=%2)&lt;/span&gt;</source>
        <translation>Totalbeløb %1&lt;span style='font-size:10pt;font-weight:normal;'&gt;&lt;br /&gt;(=%2)&lt;/span&gt;</translation>
    </message>
    <message>
        <source>or</source>
        <translation>eller</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Modtagerens adresse er ikke gyldig. Tjek venligst adressen igen.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Beløbet til betaling skal være større end 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Beløbet overstiger din saldo.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Totalen overstiger din saldo, når transaktionsgebyret på %1 er inkluderet.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Duplikeret adresse fundet. Du kan kun sende til hver adresse én gang pr. afsendelse.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Oprettelse af transaktion mislykkedes!</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Transaktionen blev afvist! Dette kan ske, hvis nogle af dine litecoins i din tegnebog allerede er brugt, som hvis du brugte en kopi af wallet.dat og dine litecoins er blevet brugt i kopien, men ikke er markeret som brugt her.</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an insanely high fee.</source>
        <translation>Et gebyr højere end %1 anses som et vanvittigt højt gebyr.</translation>
    </message>
    <message>
        <source>Pay only the minimum fee of %1</source>
        <translation>Betal kun det minimale gebyr på %1</translation>
    </message>
    <message>
        <source>Estimated to begin confirmation within %1 block(s).</source>
        <translation>Bekræftelse vurderes at begynde inden for %1 blok(ke).</translation>
    </message>
    <message>
        <source>Warning: Invalid Sucrecoin address</source>
        <translation>Advarsel: Ugyldig Sucrecoin-adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Advarsel: Ukendt byttepengeadresse</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Kopiér støv</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Er du sikker på, at du vil sende?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>tilføjet som transaktionsgebyr</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Beløb:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Betal &amp;til:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Indtast en mærkat for denne adresse for at føje den til din adressebog</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Mærkat:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Vælg tidligere brugt adresse</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Dette er en normal betaling.</translation>
    </message>
    <message>
        <source>The Sucrecoin address to send the payment to</source>
        <translation>Sucrecoin-adresse, som betalingen skal sendes til</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Indsæt adresse fra udklipsholderen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Fjern denne indgang</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Besked:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>Dette er en verificeret betalingsanmodning.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Indtast et mærkat for denne adresse for at føje den til listen over brugte adresser</translation>
    </message>
    <message>
        <source>A message that was attached to the litecoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Sucrecoin network.</source>
        <translation>En besked, som blev føjet til "bitcon:"-URI'en, som vil gemmes med transaktionen til din reference. Bemærk: Denne besked vil ikke blive sendt over Sucrecoin-netværket.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>Dette er en ikke-verificeret betalingsanmodning.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Betal til:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Sucrecoin Core is shutting down...</source>
        <translation>Sucrecoin Core lukker ned …</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Luk ikke computeren ned, før dette vindue forsvinder.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signature - Underskriv/verificér en besked</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Underskriv besked</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Du kan underskrive beskeder med dine Sucrecoin-adresser for at bevise, at de tilhører dig. Pas på ikke at underskrive noget vagt, da phisingangreb kan narre dig til at overdrage din identitet. Underskriv kun fuldt detaljerede udsagn, du er enig i.</translation>
    </message>
    <message>
        <source>The Sucrecoin address to sign the message with</source>
        <translation>Sucrecoin-adresse, som beskeden skal signeres med</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Vælg tidligere brugt adresse</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Indsæt adresse fra udklipsholderen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Indtast her beskeden, du ønsker at underskrive</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Underskrift</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopiér den nuværende underskrift til systemets udklipsholder</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Sucrecoin address</source>
        <translation>Underskriv denne besked for at bevise, at Sucrecoin-adressen tilhører dig</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Underskriv &amp;besked</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Nulstil alle "underskriv besked"-felter</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Ryd &amp;alle</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verificér besked</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Indtast herunder den underskrivende adresse, beskeden (inkludér linjeskift, mellemrum mv. nøjagtigt, som de fremgår) og underskriften for at verificere beskeden. Vær forsigtig med ikke at lægge mere i underskriften end besked selv, så du undgår at blive narret af et man-in-the-middle-angreb.</translation>
    </message>
    <message>
        <source>The Sucrecoin address the message was signed with</source>
        <translation>Sucrecoin-adressen, som beskeden blev signeret med</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Sucrecoin address</source>
        <translation>Verificér beskeden for at sikre, at den er underskrevet med den angivne Sucrecoin-adresse</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Verificér &amp;besked</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Nulstil alle "verificér besked"-felter</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>Klik "Underskriv besked" for at generere underskriften</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Den indtastede adresse er ugyldig.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Tjek venligst adressen og forsøg igen.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Den indtastede adresse henviser ikke til en nøgle.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Tegnebogsoplåsning annulleret.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Den private nøgle for den indtastede adresse er ikke tilgængelig.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Underskrivning af besked mislykkedes.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Besked underskrevet.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Underskriften kunne ikke afkodes.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Tjek venligst underskriften, og forsøg igen.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Underskriften matcher ikke beskedens indhold.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Verificering af besked mislykkedes.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Besked verificeret.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Sucrecoin Core</source>
        <translation>Sucrecoin Core</translation>
    </message>
    <message>
        <source>The Bitcoin Core developers</source>
        <translation>Udviklerne af Bitcoin Core</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnetværk]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Åben indtil %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>konflikt</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/offline</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/ubekræftet</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 bekræftelser</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, transmitteret igennem %n knude</numerusform><numerusform>, transmitteret igennem %n knuder</numerusform></translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Kilde</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Genereret</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Fra</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Til</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>egen adresse</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>kigge</translation>
    </message>
    <message>
        <source>label</source>
        <translation>mærkat</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Kredit</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>modner efter yderligere %n blok</numerusform><numerusform>modner efter yderligere %n blokke</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>ikke accepteret</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Debet</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>Total debet</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>Total kredit</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Transaktionsgebyr</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Nettobeløb</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Besked</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>Transaktions-ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Forretningsdrivende</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to "not accepted" and it won't be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Minede litecoins skal modne %1 blokke, før de kan bruges. Da du genererede denne blok, blev den udsendt til netværket for at blive føjet til blokkæden. Hvis det ikke lykkes at få den i kæden, vil dens tilstand ændres til "ikke accepteret", og den vil ikke kunne bruges. Dette kan ske nu og da, hvis en anden knude udvinder en blok inden for nogle få sekunder fra din.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Fejlsøgningsinformation</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transaktion</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Input</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>true</source>
        <translation>sand</translation>
    </message>
    <message>
        <source>false</source>
        <translation>falsk</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, er ikke blevet transmitteret endnu</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Åbn yderligere %n blok</numerusform><numerusform>Åbn yderligere %n blokke</numerusform></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>ukendt</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Transaktionsdetaljer</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Denne rude viser en detaljeret beskrivelse af transaktionen</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Umoden (%1 bekræftelser; vil være tilgængelig efter %2)</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Åbn yderligere %n blok</numerusform><numerusform>Åbn yderligere %n blokke</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Åben indtil %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Bekræftet (%1 bekræftelser)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Denne blok blev ikke modtaget af nogen andre knuder og vil formentlig ikke blive accepteret!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Genereret, men ikke accepteret</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Offline</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Ubekræftet</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Bekræfter (%1 af %2 anbefalede bekræftelser)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>Konflikt</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Modtaget med</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Modtaget fra</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Sendt til</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Betaling til dig selv</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Minet</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>kigge</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaktionsstatus. Hold musen over dette felt for at vise antallet af bekræftelser.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Dato og klokkeslæt for modtagelse af transaktionen.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Transaktionstype.</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>Afgør hvorvidt en kigge-adresse er involveret i denne transaktion.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Destinationsadresse for transaktion.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Beløb trukket fra eller tilføjet balance.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>I dag</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Denne uge</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Denne måned</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Sidste måned</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Dette år</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Interval …</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Modtaget med</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Sendt til</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Til dig selv</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Minet</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Andet</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Indtast adresse eller mærkat for at søge</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimumsbeløb</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiér adresse</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiér mærkat</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiér beløb</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopiér transaktions-ID</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Redigér mærkat</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Vis transaktionsdetaljer</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Historik for eksport af transaktioner</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>Kigge</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Eksport mislykkedes</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>En fejl opstod under gemning af transaktionshistorik til %1.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Eksport problemfri</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Transaktionshistorikken blev gemt til %1 med succes.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommasepareret fil (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bekræftet</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Interval:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>til</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>Enhed, som beløb vises i. Klik for at vælge en anden enhed.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Ingen tegnebog er indlæst.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Send litecoins</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Eksportér</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportér den aktuelle visning til en fil</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Sikkerhedskopiér tegnebog</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Tegnebogsdata (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Sikkerhedskopiering mislykkedes</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Der skete en fejl under gemning af tegnebogsdata til %1.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Tegnebogsdata blev gemt til %1 med succes.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Sikkerhedskopiering problemfri</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Indstillinger:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Angiv datamappe</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Forbind til en knude for at modtage adresser på andre knuder, og afbryd derefter</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Angiv din egen offentlige adresse</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Acceptér kommandolinje- og JSON-RPC-kommandoer</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Kør i baggrunden som en service, og acceptér kommandoer</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Brug testnetværket</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Acceptér forbindelser udefra (standard: 1 hvis hverken -proxy eller -connect)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Tildel til den givne adresse og lyt altid på den. Brug [vært]:port-notation for IPv6</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>Slet alle transaktioner i tegnebogen og genskab kun disse dele af blokkæden gennem -rescan under opstart</translation>
    </message>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file COPYING or &lt;http://www.opensource.org/licenses/mit-license.php&gt;.</source>
        <translation>Distribueret under MIT-softwarelicensen; se den vedlagte fil COPYING eller &lt;http://www.opensource.org/licenses/mit-license.php&gt;.</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation>Start regressionstesttilstand, som bruger en speciel kæde, hvor blokke kan løses med det samme.</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Udfør kommando, når en transaktion i tegnebogen ændres (%s i kommandoen erstattes med TxID)</translation>
    </message>
    <message>
        <source>In this mode -genproclimit controls how many blocks are generated immediately.</source>
        <translation>I denne tilstand styrer -genproclimit hvor mange blokke, der genereres med det samme.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Sæt antallet af scriptverificeringstråde (%u til %d, 0 = auto, &lt;0 = efterlad det antal kernet fri, standard: %d)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Dette er en foreløbig testudgivelse - brug på eget ansvar - brug ikke til udvinding eller handelsprogrammer</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. Sucrecoin Core is probably already running.</source>
        <translation>Ikke i stand til at tildele til %s på denne computer. Sucrecoin Core kører sansynligvis allerede.</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Advarsel: -paytxfee er sat meget højt! Dette er det gebyr du vil betale, hvis du sender en transaktion.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Advarsel: Netværket ser ikke ud til at være fuldt ud enige! Enkelte minere ser ud til at opleve problemer.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Advarsel: Vi ser ikke ud til at være fuldt ud enige med andre knuder! Du kan være nødt til at opgradere, eller andre knuder kan være nødt til at opgradere.</translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Advarsel: fejl under læsning af wallet.dat! Alle nøgler blev læst korrekt, men transaktionsdata eller adressebogsposter kan mangle eller være forkerte.</translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Advarsel: wallet.dat ødelagt, data reddet! Oprindelig wallet.dat gemt som wallet.{timestamp}.bak i %s; hvis din saldo eller dine transaktioner er forkert, bør du genskabe fra en sikkerhedskopi.</translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given netmask or IP address. Can be specified multiple times.</source>
        <translation>Sæt andre knuder, der forbinder fra den angivne netmaske eller IP, på hvidliste. Kan angives flere gange.</translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation>(standard: 1)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;kategori&gt; kan være:</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Forsøg at genskabe private nøgler fra ødelagt wallet.dat</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Blokoprettelsestilvalg:</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>Tilslut kun til de(n) angivne knude(r)</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Tilvalg for forbindelser:</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Ødelagt blokdatabase opdaget</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Tilvalg for fejlfinding/test:</translation>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Find egen IP-adresse (standard: 1 når lytter og ingen -externalip)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Indlæs ikke tegnebogen og slå tegnebogs-RPC-kald fra</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Ønsker du at genbygge blokdatabasen nu?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Klargøring af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Klargøring af tegnebogsdatabasemiljøet %s mislykkedes!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Indlæsning af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Åbning af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Fejl: Mangel på ledig diskplads!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Lytning på enhver port mislykkedes. Brug -listen=0, hvis du ønsker dette.</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation>Hvis &lt;kategori&gt; ikke angives, udskriv al fejlsøgningsinformation.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importerer …</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Ukorrekt eller ingen tilblivelsesblok fundet. Forkert datamappe for netværk?</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>Ugyldig -onion adresse: "%s"</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>For få tilgængelige fildeskriptorer.</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Tilslut kun til knuder i netværk &lt;net&gt; (IPv4, IPv6 eller Onion)</translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Genbyg blokkædeindeks fra nuværende blk000??.dat filer</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Sæt cache-størrelse for database i megabytes (%d til %d; standard: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Sæt maksimum blokstørrelse i byte (standard: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Angiv tegnebogsfil (inden for datamappe)</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>This is intended for regression testing tools and app development.</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>Brug UPnP til at konfigurere den lyttende port (standard: %u)</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verificerer blokke …</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verificerer tegnebog …</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Tegnebog %s findes uden for datamappe %s</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Tilvalg for tegnebog:</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>Du er nødt til at genopbygge databasen ved hjælp af -reindex for at ændre -txindex</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Importerer blokke fra ekstern blk000??.dat fil</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>Tillad JSON-RPC-forbindelser fra angivet kilde. Gyldig for &lt;ip&gt; er en enkelt IP (fx 1.2.3.4), et netværk/netmaske (fx 1.2.3.4/255.255.255.0) eller et netværk/CIDR (fx 1.2.3.4/24). Dette tilvalg kan angives flere gange</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC address %s port %u for listening: %s</source>
        <translation>Der opstod en fejl under opsætning af RPC-adresse %s port %u for lytning: %s</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>Tildel given adresse og sæt andre knuder, der forbinder til den, på hvidliste. Brug [vært]:port notation for IPv6</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>Tildel til den givne adresse for at lytte efter JSON-RPC-forbindelser. Brug [vært]:port-notation for IPv6. Denne valgmulighed kan angives flere gange (standard: tildel til alle grænseflader)</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. Sucrecoin Core is probably already running.</source>
        <translation>Kan ikke opnå en lås på datamappe %s. Sucrecoin Core kører sansynligvis allerede.</translation>
    </message>
    <message>
        <source>Continuously rate-limit free transactions to &lt;n&gt;*1000 bytes per minute (default:%u)</source>
        <translation>Rate-begræns kontinuerligt gratis transaktioner til &lt;n&gt;*1000 byte i minuttet (standard: %u)</translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>Opret nye filer med systemstandard for rettigheder i stedet for umask 077 (kun virksomt med tegnebogsfunktionalitet slået fra)</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Fejl: Lytning efter indkommende forbindelser mislykkedes (lytning resultarede i fejl %s)</translation>
    </message>
    <message>
        <source>Error: Unsupported argument -socks found. Setting SOCKS version isn't possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>Fejl: Ikke understøttet argument -socks blev fundet. Det er ikke muligt at angive SOCKS-version længere, da kun SOCKS5-proxier er understøttet.</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Udfør kommando, når en relevant alarm modtages eller vi ser en virkelig lang udsplitning (%s i cmd erstattes af besked)</translation>
    </message>
    <message>
        <source>Fees (in LTC/Kb) smaller than this are considered zero fee for relaying (default: %s)</source>
        <translation>Gebyrer (i LTC/Kb) mindre end dette opfattes som nulgebyr for videresendelse (standard: %s)</translation>
    </message>
    <message>
        <source>Fees (in LTC/Kb) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>Gebyrer (i LTC/Kb) mindre end dette opfattes som nulgebyr for oprettelse af transaktion (standard: %s)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>Hvis paytxfee ikke er sat, inkluderes nok gebyr til at transaktioner begynder at blive bekræftet ingen for gennemsnitligt n blokke (standard: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: '%s' (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>Ugyldigt beløb for -maxtxfee=&lt;beløb&gt;: "%s" (skal være på mindst minrelay-gebyret på %s for at undgå hængende transaktioner)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>Maksimal størrelse på data i transaktioner til dataoverførsel, som vi videresender og miner (standard: %u)</translation>
    </message>
    <message>
        <source>Maximum total fees to use in a single wallet transaction, setting too low may abort large transactions (default: %s)</source>
        <translation>Maksimalt totalgebyr der bruges på en enkelt tegnebogstransaktion. Sættes det for lavt kan store transaktioner afbrydes (standard: %s)</translation>
    </message>
    <message>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect)</source>
        <translation>Forespørgsel</translation>
    </message>
    <message>
        <source>Require high priority for relaying free or low-fee transactions (default:%u)</source>
        <translation>Kræv høj prioritet for at videresende transaktioner med intet eller lavt gebyr (standard: %u)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Sæt maksimumstørrelse for højprioritet/lavgebyr-transaktioner i byte (standard: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads for coin generation if enabled (-1 = all cores, default: %d)</source>
        <translation>Sæt antaller af tråde for coin-generering, hvis aktiveret (-1 = alle kerner, standard: %d)</translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit &lt;https://www.openssl.org/&gt; and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard.</source>
        <translation>Dette produkt indeholder software, der er udviklet af OpenSSL-projektet for brug i OpenSSL-værktøjskassen &lt;https://www.openssl.org/&gt;, samt kryptografisk software, der er skrevet af Eric Young, samt UPnP-software, der er skrevet af Thomas Bernard.</translation>
    </message>
    <message>
        <source>To use litecoind, or the -server option to litecoin-qt, you must set an rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=litecoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s "Sucrecoin Alert" admin@foo.com
</source>
        <translation>For at bruge litecoind eller valgmuligheden -server i litecoin-qt skal du oprette et rpcpassword i konfigurationsfilen:
%s
Det anbefales, at du bruger følgende tilfældige adgangskode:
rpcuser=litecoinrpc
rpcpassword=%s
(du behøver ikke at huske adgangskoden)
Brugernavnet og adgangskoden MÅ IKKE være det samme.
Hvis filen ikke eksisterer, opret den da så kun ejeren har læserettigheder.
Det anbefales også at sætte alertnotify, så du får besked omkring problemer;
for eksempel: alertnotify=echo %%s | mail -s "Sucrecoin Alert" admin@foo.com
</translation>
    </message>
    <message>
        <source>Warning: -maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>Advarsel: -maxtxfee er sat meget højt! Så store gebyrer kan betales på en enkelt transaktion.</translation>
    </message>
    <message>
        <source>Warning: Please check that your computer's date and time are correct! If your clock is wrong Sucrecoin Core will not work properly.</source>
        <translation>Advarsel: Undersøg venligst at din computers dato og klokkeslet er korrekt indstillet! Hvis der er fejl i disse vil Sucrecoin Core ikke fungere korrekt.</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>Andre knuder på hvidliste kan ikke DoS-bandlyses, og deres transaktioner videresendes altid, selv hvis de allerede er i mempool'en. Brugbart til fx et adgangspunkt</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>Acceptér offentlige REST-anmodninger (standard: %u)</translation>
    </message>
    <message>
        <source>Cannot resolve -whitebind address: '%s'</source>
        <translation>Kan ikke løse -whitebind adresse: "%s"</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Forbind gennem SOCKS5-proxy</translation>
    </message>
    <message>
        <source>Copyright (C) 2009-%i The Bitcoin Core Developers</source>
        <translation>Ophavsret © 2009-%i Udviklerne af Bitcoin Core</translation>
    </message>
    <message>
        <source>Could not parse -rpcbind value %s as network address</source>
        <translation>Kunne ikke tolke -rpcbind-værdi %s som en netværksadresse</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet requires newer version of Sucrecoin Core</source>
        <translation>Fejl ved indlæsning af wallet.dat: Tegnebog kræver en nyere version af Sucrecoin Core</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Fejl under læsning fra database; lukker ned.</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Fejl: En alvorlig intern fejl er opstået. Se debug.log for detaljer</translation>
    </message>
    <message>
        <source>Error: Unsupported argument -tor found, use -onion.</source>
        <translation>Fejl: Ikke understøttet argument -tor fundet, brug -onion.</translation>
    </message>
    <message>
        <source>Fee (in LTC/kB) to add to transactions you send (default: %s)</source>
        <translation>Gebyr (i LTC/kB) som skal føjes til transaktioner, du sender (standard: %s)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. Sucrecoin Core is shutting down.</source>
        <translation>Sundhedstjek under klargøring mislykkedes. Sucrecoin Core lukker ned.</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ugyldigt beløb for -maxtxfee=&lt;beløb&gt;: "%s"</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ugyldigt beløb til -minrelaytxfee=&lt;beløb&gt;: "%s"</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ugyldigt beløb til -mintxfee=&lt;beløb&gt;: "%s"</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s' (must be at least %s)</source>
        <translation>Ugyldigt beløb for -paytxfee=&lt;beløb&gt;: "%s" (skal være mindst %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: '%s'</source>
        <translation>Ugyldig netmaske angivet i -whitelist: "%s"</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>Behold højest &lt;n&gt; uforbindelige transaktioner i hukommelsen (standard: %u)</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: '%s'</source>
        <translation>Nødt til at angive en port med -whitebinde: "%s"</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Videresendelsesvalgmuligheder for knude:</translation>
    </message>
    <message>
        <source>RPC SSL options: (see the Sucrecoin Wiki for SSL setup instructions)</source>
        <translation>Tilvalg for RPC SSL: (se Sucrecoin Wiki for instruktioner i SSL-opstart)</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>Tilvalg for RPC-server:</translation>
    </message>
    <message>
        <source>RPC support for HTTP persistent connections (default: %d)</source>
        <translation>RPC-understøttelse for HTTP-persistente forbindelser (standard: %d)</translation>
    </message>
    <message>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation>Drop tilfældigt 1 ud af hver &lt;n&gt; netværksbeskeder</translation>
    </message>
    <message>
        <source>Randomly fuzz 1 of every &lt;n&gt; network messages</source>
        <translation>Slør tilfældigt 1 ud af hver &lt;n&gt; netværksbeskeder</translation>
    </message>
    <message>
        <source>Receive and display P2P network alerts (default: %u)</source>
        <translation>Modtag og vis P2P-netværksadvarsler (standard: %u)</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Send sporings-/fejlsøgningsinformation til konsollen i stedet for debug.log filen</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>Send transaktioner som nul-gebyr-transaktioner hvis muligt (standard: %u)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Vis alle tilvalg for fejlsøgning (brug: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Formindsk debug.log filen ved klientopstart (standard: 1 hvis ikke -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Underskrift af transaktion mislykkedes</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Dette er eksperimentelt software.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transaktionsbeløb er for lavt</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>Transaktionsbeløb skal være positive</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Transaktion for stor til gebyrretningslinjer</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transaktionen er for stor</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Ikke i stand til at tildele til %s på denne computer (bind returnerede fejl %s)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Brug UPnP til at konfigurere den lyttende port (standard: 1 under lytning)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Brugernavn til JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart Sucrecoin Core to complete</source>
        <translation>Det var nødvendigt at genskrive tegnebogen: genstart Sucrecoin Core for at gennemføre</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Advarsel: Denne version er forældet, opgradering påkrævet!</translation>
    </message>
    <message>
        <source>Warning: Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>Advarsel: Ikke understøttet argument -benchmark ignoreret, brug -debug=bench.</translation>
    </message>
    <message>
        <source>Warning: Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Advarsel: Ikke understøttet argument -debugnet ignoreret, brug -debug=net.</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Zapper alle transaktioner fra tegnebog …</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>under opstart</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat ødelagt, redning af data mislykkedes</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Adgangskode til JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Udfør kommando, når den bedste blok ændres (%s i kommandoen erstattes med blokhash)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>Opgrader tegnebog til seneste format</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Gennemsøg blokkæden for manglende tegnebogstransaktioner</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Brug OpenSSL (https) for JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Denne hjælpebesked</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Tillad DNS-opslag for -addnode, -seednode og -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Indlæser adresser …</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Fejl ved indlæsning af wallet.dat: Tegnebog ødelagt</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 = behold metadata for transaktion, fx kontoindehaver og information om betalingsanmodning, 2 = drop metadata for transaktion)</translation>
    </message>
    <message>
        <source>Flush database activity from memory pool to disk log every &lt;n&gt; megabytes (default: %u)</source>
        <translation>Flyt databaseaktivitet fra hukommelsespulje til disklog hver &lt;n&gt; megabyte (standard: %u)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>Hvor gennemarbejdet blokverificeringen for -checkblocks er (0-4; standard: %u)</translation>
    </message>
    <message>
        <source>Log transaction priority and fee per kB when mining blocks (default: %u)</source>
        <translation>Prioritet for transaktionslog og gebyr pr. kB under udvinding af blokke (standard: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>Vedligehold et komplet transaktionsindeks, der bruges af rpc-kaldet getrawtransaction (standard: %u)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>Antal sekunder, som knuder der opfører sig upassende, skal vente før reetablering (standard: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>Udskriv fejlsøgningsinformation (standard: %u, angivelse af &lt;kategori&gt; er valgfri)</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>Brug separat SOCS5-proxy for at nå andre knuder via Tor skjulte tjenester (standard: %s)</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(standard: %s)</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: %s)</source>
        <translation>Accepterede kodninger (standard: %s)</translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>Forespørg altid adresser på andre knuder via DNS-opslag (default: %u)</translation>
    </message>
    <message>
        <source>Disable safemode, override a real safe mode event (default: %u)</source>
        <translation>Slå sikker tilstand fra, tilsidesæt hændelser fra sikker tilstand (standard: %u)</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Fejl ved indlæsning af wallet.dat</translation>
    </message>
    <message>
        <source>Force safe mode (default: %u)</source>
        <translation>Gennemtving sikker tilstand (standard: %u)</translation>
    </message>
    <message>
        <source>Generate coins (default: %u)</source>
        <translation>Generér litecoins (standard: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>Antal blokke som tjekkes ved opstart (standard: %u, 0 = alle)</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>Inkludér IP-adresser i fejlretningsoutput (standard: %u)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Ugyldig -proxy adresse: "%s"</translation>
    </message>
    <message>
        <source>Limit size of signature cache to &lt;n&gt; entries (default: %u)</source>
        <translation>Begræns størrelsen på signaturcache til &lt;n&gt; indgange (standard: %u)</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Lyt efter JSON-RPC-forbindelser på &lt;port&gt; (standard: %u eller testnet: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Lyt efter forbindelser på &lt;port&gt; (standard: %u eller testnet: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>Oprethold højest &lt;n&gt; forbindelser til andre knuder (standard: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maksimum for modtagelsesbuffer pr. forbindelse, &lt;n&gt;*1000 byte (standard: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maksimum for afsendelsesbuffer pr. forbindelse, &lt;n&gt;*1000 byte (standard: %u)</translation>
    </message>
    <message>
        <source>Only accept block chain matching built-in checkpoints (default: %u)</source>
        <translation>Acceptér kun indbyggede kontrolposter, der matcher blokkæden (standard: %u)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>Føj tidsstempel foran fejlsøgningsoutput (standard: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>Videresend og udvind databærer-transaktioner (standard: %u)</translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>Videresend ikke-P2SH multisig (standard: %u)</translation>
    </message>
    <message>
        <source>Run a thread to flush wallet periodically (default: %u)</source>
        <translation>Kør en tråd for periodisk at rydde tegnebog (standard: %u)</translation>
    </message>
    <message>
        <source>Server certificate file (default: %s)</source>
        <translation>Servercertifikat-fil (standard: %s)
</translation>
    </message>
    <message>
        <source>Server private key (default: %s)</source>
        <translation>Serverens private nøgle (standard: %s)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>Sæt nøglepuljestørrelse til &lt;n&gt; (standard: %u)
</translation>
    </message>
    <message>
        <source>Set minimum block size in bytes (default: %u)</source>
        <translation>Angiv minimumsblokstørrelse i byte (standard: %u)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>Angiv antallet af tråde til at håndtere RPC-kald (standard: %d)</translation>
    </message>
    <message>
        <source>Sets the DB_PRIVATE flag in the wallet db environment (default: %u)</source>
        <translation>Sætter DB_PRIVATE-flaget i tegnebogens db-miljø (standard: %u)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Angiv konfigurationsfil (standard: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Angiv tilslutningstimeout i millisekunder (minimum: 1, standard: %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>Angiv pid-fil (standard: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>Brug ubekræftede byttepenge under afsendelse af transaktioner (standard: %u)</translation>
    </message>
    <message>
        <source>Stop running after importing blocks from disk (default: %u)</source>
        <translation>Stop kørsel efter import af blokke fra disk (standard: %u)</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>Grænse for afbrydelse af forbindelse til knuder, der opfører sig upassende (standard: %u)</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>Ukendt netværk anført i -onlynet: "%s"</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: '%s'</source>
        <translation>Kan ikke finde -bind adressen: "%s"</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: '%s'</source>
        <translation>Kan ikke finde -externalip adressen: "%s"</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ugyldigt beløb for -paytxfee=&lt;beløb&gt;: "%s"</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Manglende dækning</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Indlæser blokindeks …</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Tilføj en knude til at forbinde til og forsøg at holde forbindelsen åben</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Indlæser tegnebog …</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Kan ikke nedgradere tegnebog</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Kan ikke skrive standardadresse</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Genindlæser …</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Indlæsning gennemført</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
</context>
</TS>
